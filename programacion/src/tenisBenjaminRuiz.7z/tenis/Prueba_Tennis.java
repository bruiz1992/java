package Tema5;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Prueba_Tennis {
	

	public static void main(String[] args) {		
	
		System.out.println("\nCUARTOS DE FINAL DE ROLAND GARROS\n");
		System.out.print("Introduzca el nombre del 1er equipo: ");
		Scanner entrada = new Scanner(System.in);
		String nombre1 = entrada.nextLine();
		
		System.out.print("Jugador 1: ");
		String nombreJ1 = entrada.nextLine();
		Jugador jugador1 = new Jugador(nombreJ1);
		
		System.out.print("Jugador 2: ");
		String nombreJ2 = entrada.nextLine();
		Jugador jugador2 = new Jugador(nombreJ2);
	
	
		Equipo equipo1 = new Equipo(nombre1, jugador1, jugador2);
	
		System.out.print("Introduzca el nombre del 2 equipo: ");
		String nombre2 = entrada.nextLine();
		
		System.out.print("Jugador 1: ");
		String nombreJ12 = entrada.nextLine();
		Jugador jugador12 = new Jugador(nombreJ12);
		
		System.out.print("Jugador 2: ");
		String nombreJ22 = entrada.nextLine();
		Jugador jugador22 = new Jugador(nombreJ22);
	
	
		Equipo equipo2 = new Equipo(nombre2, jugador12, jugador22);
		String nombre_partido = nombre1 + "-" + nombre2;
		
		Partido partido = new Partido(nombre_partido, equipo1, equipo2);
		
		boolean salir = false;
		int opcion;
	
		while (!salir) {
			System.out.println("\nEstad�sticas\n"+"-".repeat("Estad�sticas".length()));
		    System.out.println("1.  	Contabiliza punto ganador");
		    System.out.println("2.	Contabiliza error no forzado");
		    System.out.println("3.	Contabiliza saque directo");
		   
		    System.out.println("4.	Muestra estad�sticas jugador");
		    System.out.println("5.	Muestra estad�sticas del equipo");
		    System.out.println("6.	Salir del programa.");
		    
		    try {
	    		System.out.print("\n    Opci�n: ");
				opcion = entrada.nextInt();
				switch (opcion) {
				case 1:
						System.out.println("* CONTABILIZA PUNTO GANADOR *");
						System.out.print("Nombre del jugador: ");
						String nombre = entrada.nextLine();
						partido.addEstadisticas(opcion, nombre);
						
						break;
						
				case 2:
						System.out.println("* CONTABILIZA ERROR NO FORZADO *");
						System.out.print("Nombre del jugador: ");
						String nombreError = entrada.nextLine();
						partido.addEstadisticas(opcion, nombreError);
						break;
						
					case 3:
						System.out.println("* CONTABILIZA SAQUE DIRECTO *");
						System.out.print("Nombre del jugador: ");
						String nombreSaque = entrada.nextLine();
						partido.addEstadisticas(opcion, nombreSaque);
						break;
						
						break;
					case 4:
						System.out.println("* Estadisticas Jugador *");
						System.out.print("Nombre del jugador: ");
						String nombreE = entrada.nextLine();
						System.out.println(partido.existeJugador(nombreE).toString());
						
						break;
					case 5:
						System.out.println("* Estadisticas Equipo *");
						System.out.print("Nombre del equipo: ");
						String nombreEquipo = entrada.nextLine();
						partido.existeEquipo(nombreEquipo);
						break;
					case 6:
				         salir = true;
				        System.out.println("Exit");	
				        break;
			            
					default :
						System.out.println(" Las opciones son entre 1 y 6.");
						entrada.nextLine();
				}
			} catch(InputMismatchException e) {
				System.out.println(" Debes introducir un numero.");
			}	
		}	
	}	
}

