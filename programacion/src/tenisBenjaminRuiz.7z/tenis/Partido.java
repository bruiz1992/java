package Tema5;
public class Partido {
	//Atributos:
	
	String nombre_partido;
	Equipo equipo1;
	Equipo equipo2;

	//Constructor:
	
	Partido(String nombre_partido,Equipo equipo1, Equipo equipo2) { 
		
		this.nombre_partido = nombre_partido;
		this.equipo1 = equipo1;
		this.equipo2 = equipo2;
	}
	//METODOS GET, SET, toString
	
	public String getNombre_partido() {
		return nombre_partido;
	}
	public void setNombre_partido(String nombre_partido) {
		this.nombre_partido = nombre_partido;
	}
	public Equipo getEquipo1() {
		return equipo1;
	}
	public void setEquipo1(Equipo equipo1) {
		this.equipo1 = equipo1;
	}
	public Equipo getEquipo2() {
		return equipo2;
	}
	public void setEquipo2(Equipo equipo2) {
		this.equipo2 = equipo2;
	}
	@Override
	public String toString() {
		return "Partido [nombre_partido=" + nombre_partido + ", equipo1=" + equipo1 + ", equipo2=" + equipo2 + "]";
	}
	/* Metodo para ver si tengo el nombre del equipo
	 * 
	 */
	public boolean existeEquipo(String Nombre) {
		if(getEquipo1().getNombre_equipo().equals(Nombre)) {
			return true;
		} else if (getEquipo2().getNombre_equipo().equals(Nombre)) {
			return true;
		}
		return false;
	}

	public void addEstadisticas(int opcion, String nombre) {
		// TODO Auto-generated method stub
		
	}


	public String obtenerJugador(String nombreJugador) {
		
		boolean encontrado = false;
		String jugadorBuscado = null;
		while (!encontrado) {
			if(equipo1.existeJugador(nombreJugador).equalsIgonerecase(nombre)) {
				encontrado = true;
				jugadorBuscado = nombreJugador;
			}else if (equipo2.existeJugador(nombreJugador).equals(nombre)){
				encontrado = true;
				jugadorBuscado = nombreJugador;
			} 
		}
		return jugadorBuscado;
	}
	
	
	
	/* Metodo para anadir estadisticas
	 * 
	 
	public void addEstadistica(int opcion, String Nombre) {
		if ((opcion == 1) && (existeEquipo(Nombre) == true)) {
			addEstadistica.
			 
		}
			getEquipo1().addEstadistica(opcion, Nombre);
		} else if (getEquipo2().existeJugador(Nombre)){
			getEquipo2().addEstadistica(opcion, Nombre);
		}
	}*/
	
	
	/*
	 * Proporciona un objeto de tipo Jugador, a partir del nombre de dicho jugador.
	 * @param Jugador jugador.
	 */	
	/* Metodos para anadir puntos para jugador
	 * 
	 */
	

	
	/*public void addPuntos_ganadores(String nombre) {
		if(getEquipo1().existeJugador(nombre) || getEquipo2().existeJugador(nombre)) {
			Jugador jugador11 = getEquipo1().getJugador1();
			Jugador jugador21 = getEquipo1().getJugador2();
			Jugador jugador12 = getEquipo2().getJugador1();
			Jugador jugador22 = getEquipo2().getJugador2();
			int puntos = 0;
			if (nombre.equals(getEquipo1().getJugador1().getNombre())) {
				puntos = jugador11.getPuntos_ganadores();
				puntos++;
				jugador11.setPuntos_ganadores(puntos);
			}else if (nombre.equals(getEquipo1().getJugador2().getNombre())) {
				puntos = jugador21.getPuntos_ganadores();
				puntos++;
				jugador21.setPuntos_ganadores(puntos);
			}else if (nombre.equals(getEquipo2().getJugador1().getNombre())) {	
				puntos = jugador12.getPuntos_ganadores();
				puntos++;
				jugador12.setPuntos_ganadores(puntos);
			}else if (nombre.equals(getEquipo2().getJugador2().getNombre())) {
				puntos = jugador22.getPuntos_ganadores();
				puntos++;
				jugador22.setPuntos_ganadores(puntos);
			}
		} 
	}
			
	public void adderrores(String nombre) {
		if(getEquipo1().existeJugador(nombre) || getEquipo2().existeJugador(nombre)) {
			Jugador jugador1 = getEquipo1().getJugador1();
			Jugador jugador2 = getEquipo1().getJugador2();
			int errores = 0;
			if (nombre.equals(jugador1.getNombre())) {
				errores = jugador1.getErrores();
				errores++;
				jugador1.setErrores(errores);
			}else if (nombre.equals(jugador2.getNombre())) {
				errores = jugador2.getErrores();
				errores++;
				jugador2.setErrores(errores);
			}else if (nombre.equals(getEquipo2().getJugador1().getNombre())) {	
				errores = getEquipo2().getJugador1().getErrores();
				errores++;
				getEquipo2().getJugador1().setErrores(errores);
			}else if (nombre.equals(getEquipo2().getJugador2().getNombre())) {
				errores = getEquipo2().getJugador2().getErrores();
				errores++;
				getEquipo2().getJugador2().setErrores(errores);
			}
		} 
	}
		
	public void addSaques_directos(String nombre) {
		if(getEquipo1().existeJugador(nombre) || getEquipo2().existeJugador(nombre)) {
			Jugador jugador1 = getEquipo1().getJugador1();
			Jugador jugador2 = getEquipo1().getJugador2();
			
			int saques = 0;
			if (nombre.equals(jugador1.getNombre())) {
				saques = jugador1.getSaques_directos();
				saques++;
				jugador1.setSaques_directos(saques);
			}else if (nombre.equals(jugador2.getNombre())) {
				saques = jugador2.getSaques_directos();
				saques++;
				jugador2.setSaques_directos(saques);
			}else if (nombre.equals(getEquipo2().getJugador1().getNombre())) {	
				saques = getEquipo2().getJugador1().getSaques_directos();
				saques++;
				getEquipo2().getJugador1().setSaques_directos(saques);
			}else if (nombre.equals(getEquipo2().getJugador2().getNombre())) {
				saques = getEquipo2().getJugador2().getSaques_directos();
				saques++;
				getEquipo2().getJugador2().setSaques_directos(saques);
			}
		} 
	}

	public int[] estadisticasJugador(String nombre) {
		//Es que si separo esto y lo pongo parte en Equipo, 
		//Cuando yo quiera devolver por ejemplo los jugadores voy a tener que usar
		//arrays que contengan los 2 jugadores, [jugador1, jugador2] o sus estadisticas:
		//[Puntos, Errores, Saques] y tener que trabajar con arrays es mas complicado
		//que escribir unas pocas lineas mas y tener todo mas limpio y facil.
		Jugador jugador11 = getEquipo1().getJugador1();
		Jugador jugador21 = getEquipo1().getJugador2();
		Jugador jugador12 = getEquipo2().getJugador1();
		Jugador jugador22 = getEquipo2().getJugador2();
		int [] estadisticas = new int[3];
		if (nombre.equals(jugador11.getNombre())) {
			estadisticas[0] = jugador11.getPuntos_ganadores();
			estadisticas[1] = jugador11.getErrores();
			estadisticas[2]	= jugador11.getSaques_directos();
		} else if (nombre.equals(jugador12.getNombre())) {
			estadisticas[0] = jugador12.getPuntos_ganadores();
			estadisticas[1] = jugador12.getErrores();
			estadisticas[2]	= jugador12.getSaques_directos();
		} else if (nombre.equals(jugador21.getNombre())) {
			estadisticas[0] = jugador21.getPuntos_ganadores();
			estadisticas[1] = jugador21.getErrores();
			estadisticas[2]	= jugador21.getSaques_directos();
		} else if (nombre.equals(jugador22.getNombre())) {
			estadisticas[0] = jugador22.getPuntos_ganadores();
			estadisticas[1] = jugador22.getErrores();
			estadisticas[2]	= jugador22.getSaques_directos();
		}
		return estadisticas;
	}
	public int[] estadisticasEquipo(String nombre) {
		String nombre_equipo1 = getEquipo1().getNombre_equipo();
		String nombre_equipo2 = getEquipo2().getNombre_equipo();
		int [] estadisticas = new int[3];
		if (nombre.equals(nombre_equipo1)) {
			Equipo equipo1 = getEquipo1();
			Jugador jugador1 = equipo1.getJugador1();
			Jugador jugador2 = equipo1.getJugador2();
			
			int puntosEquipo = jugador1.getPuntos_ganadores() + jugador2.getPuntos_ganadores();
			int erroresEquipo = jugador1.getErrores() + jugador2.getErrores();
			int saquesEquipo = jugador1.getSaques_directos() + jugador2.getSaques_directos();			
			
			estadisticas[0] = puntosEquipo;
			estadisticas[1] = erroresEquipo;
			estadisticas[2]	= saquesEquipo;
		} else if (nombre.equals(nombre_equipo2)) {
			Equipo equipo2 = getEquipo2();
			Jugador jugador1 = equipo2.getJugador1();
			Jugador jugador2 = equipo2.getJugador2();
			
			int puntosEquipo = jugador1.getPuntos_ganadores() + jugador2.getPuntos_ganadores();
			int erroresEquipo = jugador1.getErrores() + jugador2.getErrores();
			int saquesEquipo = jugador1.getSaques_directos() + jugador2.getSaques_directos();			
			
			estadisticas[0] = puntosEquipo;
			estadisticas[1] = erroresEquipo;
			estadisticas[2]	= saquesEquipo;
		}
		return estadisticas;*/
	}